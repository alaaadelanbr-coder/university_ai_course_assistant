const message=document.getElementById("message");
const button=document.getElementById("askBtn");
const answer=document.getElementById("answer");
const sources=document.getElementById("sources");

button.addEventListener("click",async()=>{
  const text=message.value.trim();
  if(!text){answer.textContent="Please write a question.";return;}
  answer.textContent="Thinking...";
  sources.textContent="";
  try{
    const response=await fetch("/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text})
    });
    const data=await response.json();
    if(!response.ok) throw new Error(data.detail||"Request failed");
    answer.textContent=data.answer;
    sources.textContent=data.sources.join("\n\n---\n\n");
  }catch(error){answer.textContent="Error: "+error.message;}
});
