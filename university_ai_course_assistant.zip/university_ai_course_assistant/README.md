# University AI Course Assistant

Educational prototype similar to the University Course Syllabus & Exam Assistant.

Features:
- Grounded RAG over a syllabus
- FAISS vector store
- HuggingFace embeddings
- Groq LLM
- GPA impact tool
- Study schedule tool
- FastAPI + Pydantic
- HTML/CSS/JavaScript frontend

## Run

python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

Copy .env.example to .env and add your Groq API key.

uvicorn app.main:app --reload

Open:
http://127.0.0.1:8000/static/index.html
Swagger:
http://127.0.0.1:8000/docs

Test:
- When is the final exam?
- What is the grading distribution?
- What are the prerequisites?
- Calculate my GPA if my current GPA is 3.0, I completed 60 credits, and I get 4.0 in a 3-credit course.
- Make a 5-day study schedule for Python, NLP, and RAG with 3 hours per day.

Replace data/syllabus.txt with your own syllabus when ready.
