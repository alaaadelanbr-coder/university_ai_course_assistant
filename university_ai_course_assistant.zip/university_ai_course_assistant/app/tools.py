from langchain_core.tools import tool

@tool
def gpa_impact_simulator(current_gpa: float, completed_credits: int,
                         course_credits: int, course_grade_points: float) -> str:
    """Calculate the new GPA after adding one course."""
    if completed_credits < 0 or course_credits <= 0:
        return "Invalid credit values."
    total_points = current_gpa * completed_credits
    new_gpa = (total_points + course_grade_points * course_credits) / (
        completed_credits + course_credits
    )
    return f"Current GPA: {current_gpa:.2f}\nNew GPA: {new_gpa:.2f}"

@tool
def generate_study_schedule(topics: str, days_remaining: int,
                            hours_per_day: float) -> str:
    """Create a simple study schedule."""
    if days_remaining <= 0 or hours_per_day <= 0:
        return "days_remaining and hours_per_day must be positive."
    topic_list = [t.strip() for t in topics.split(",") if t.strip()]
    if not topic_list:
        return "Please provide at least one topic."
    return "\n".join(
        f"Day {d}: {topic_list[(d-1) % len(topic_list)]} — {hours_per_day:.1f} hours"
        for d in range(1, days_remaining + 1)
    )
