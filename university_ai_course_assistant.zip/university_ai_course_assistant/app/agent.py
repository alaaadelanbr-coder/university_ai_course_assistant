from langchain_groq import ChatGroq
from langchain.agents import create_agent

from .config import GROQ_API_KEY, LLM_MODEL
from .rag import retrieve_context
from .tools import gpa_impact_simulator, generate_study_schedule

if not GROQ_API_KEY:
    raise RuntimeError("GROQ_API_KEY is missing. Put it in .env")

model = ChatGroq(model=LLM_MODEL, api_key=GROQ_API_KEY, temperature=0)

SYSTEM_PROMPT = """You are a university course assistant for beginners.
Use syllabus context for course facts. Never invent dates, percentages, or policies.
If the requested course fact is absent, say that it was not found in the syllabus.
Use the GPA tool for GPA calculations and the study schedule tool for schedules.
Explain answers simply.
"""

agent = create_agent(
    model=model,
    tools=[gpa_impact_simulator, generate_study_schedule],
    system_prompt=SYSTEM_PROMPT,
)

def ask_agent(question: str):
    context, docs = retrieve_context(question)
    prompt = f"""Syllabus context:
---BEGIN CONTEXT---
{context}
---END CONTEXT---

Student question:
{question}

Use the context for syllabus questions. Use tools when the question asks for GPA
calculation or a study schedule.
"""
    result = agent.invoke({"messages": [{"role": "user", "content": prompt}]})
    return result["messages"][-1].content, [d.page_content for d in docs]
