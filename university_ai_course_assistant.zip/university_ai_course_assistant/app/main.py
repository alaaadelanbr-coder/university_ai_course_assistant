from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .agent import ask_agent

app = FastAPI(title="University AI Course Assistant")
app.mount("/static", StaticFiles(directory="static"), name="static")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)

class ChatResponse(BaseModel):
    answer: str
    sources: list[str]

@app.get("/")
def home():
    return {"message": "Open /static/index.html or /docs"}

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    answer, sources = ask_agent(request.message)
    return ChatResponse(answer=answer, sources=sources)
