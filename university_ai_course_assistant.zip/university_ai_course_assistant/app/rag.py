from pathlib import Path

from langchain_community.document_loaders import TextLoader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS

from .config import EMBEDDING_MODEL

DATA_FILE = Path("data/syllabus.txt")
VECTOR_DIR = Path("vectorstore")

def build_vectorstore():
    documents = TextLoader(str(DATA_FILE), encoding="utf-8").load()
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=80)
    chunks = splitter.split_documents(documents)
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local(str(VECTOR_DIR))
    return vectorstore

def get_vectorstore():
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    if VECTOR_DIR.exists():
        return FAISS.load_local(
            str(VECTOR_DIR),
            embeddings,
            allow_dangerous_deserialization=True,
        )
    return build_vectorstore()

def retrieve_context(question: str, k: int = 4):
    docs = get_vectorstore().similarity_search(question, k=k)
    return "\n\n".join(d.page_content for d in docs), docs
